// Файл для работы с localStorage (обновленный для поддержки multiple users)

// Получить текущего пользователя
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('fittrack_current_user') || 'null');
}

// Получить ID текущего пользователя
function getCurrentUserId() {
    const currentUser = getCurrentUser();
    return currentUser ? currentUser.id : null;
}

// Получить ключи для текущего пользователя
function getUserStorageKeys() {
    const userId = getCurrentUserId();
    if (!userId) return null;
    
    return {
        FOOD_ENTRIES: `fittrack_food_entries_${userId}`,
        ACTIVITY_ENTRIES: `fittrack_activity_entries_${userId}`,
        USER_GOALS: `fittrack_user_goals_${userId}`
    };
}

// Инициализация данных по умолчанию для текущего пользователя
function initializeDefaultData() {
    const keys = getUserStorageKeys();
    if (!keys) return;
    
    const currentUser = getCurrentUser();
    
    if (!localStorage.getItem(keys.USER_GOALS)) {
        const defaultGoals = currentUser?.goals || {
            dailyCalories: 2000,
            dailyProtein: 80,
            dailyCarbs: 250,
            dailyFat: 65,
            dailySteps: 10000,
            dailyActivity: 60
        };
        localStorage.setItem(keys.USER_GOALS, JSON.stringify(defaultGoals));
    }

    if (!localStorage.getItem(keys.FOOD_ENTRIES)) {
        const defaultFoodEntries = [
            { 
                id: generateId(),
                name: 'Овсяная каша', 
                calories: 150, 
                protein: 5, 
                carbs: 25, 
                fat: 3, 
                time: '08:30',
                date: getTodayDate()
            }
        ];
        localStorage.setItem(keys.FOOD_ENTRIES, JSON.stringify(defaultFoodEntries));
    }

    if (!localStorage.getItem(keys.ACTIVITY_ENTRIES)) {
        const defaultActivityEntries = [
            {
                id: generateId(),
                type: 'Ходьба',
                duration: 30,
                calories: 120,
                date: getTodayDate(),
                time: '18:00'
            }
        ];
        localStorage.setItem(keys.ACTIVITY_ENTRIES, JSON.stringify(defaultActivityEntries));
    }
}

// Генерация уникального ID
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Получение сегодняшней даты в формате YYYY-MM-DD
function getTodayDate() {
    return new Date().toISOString().split('T')[0];
}

// Получение данных пользователя
function getUserData() {
    return JSON.parse(localStorage.getItem('fittrack_user_data') || '{}');
}

// Сохранение данных пользователя
function saveUserData(userData) {
    localStorage.setItem('fittrack_user_data', JSON.stringify(userData));
}

// Получение целей пользователя
function getUserGoals() {
    const keys = getUserStorageKeys();
    if (!keys) return {};
    
    return JSON.parse(localStorage.getItem(keys.USER_GOALS) || '{}');
}

// Сохранение целей пользователя
function saveUserGoals(goals) {
    const keys = getUserStorageKeys();
    if (!keys) return;
    
    localStorage.setItem(keys.USER_GOALS, JSON.stringify(goals));
}

// Получение всех записей о питании
function getAllFoodEntries() {
    const keys = getUserStorageKeys();
    if (!keys) return [];
    
    return JSON.parse(localStorage.getItem(keys.FOOD_ENTRIES) || '[]');
}

// Получение записей о питании за определенную дату
function getFoodEntriesByDate(date = getTodayDate()) {
    const allEntries = getAllFoodEntries();
    return allEntries.filter(entry => entry.date === date);
}

// Добавление новой записи о питании
function addFoodEntry(foodData) {
    const keys = getUserStorageKeys();
    if (!keys) return null;
    
    const entries = getAllFoodEntries();
    const newEntry = {
        id: generateId(),
        date: getTodayDate(),
        ...foodData
    };
    entries.push(newEntry);
    localStorage.setItem(keys.FOOD_ENTRIES, JSON.stringify(entries));
    return newEntry;
}

// Удаление записи о питании
function deleteFoodEntry(id) {
    const keys = getUserStorageKeys();
    if (!keys) return [];
    
    const entries = getAllFoodEntries();
    const filteredEntries = entries.filter(entry => entry.id !== id);
    localStorage.setItem(keys.FOOD_ENTRIES, JSON.stringify(filteredEntries));
    return filteredEntries;
}

// Получение всех записей об активности
function getAllActivityEntries() {
    const keys = getUserStorageKeys();
    if (!keys) return [];
    
    return JSON.parse(localStorage.getItem(keys.ACTIVITY_ENTRIES) || '[]');
}

// Получение записей об активности за определенную дату
function getActivityEntriesByDate(date = getTodayDate()) {
    const allEntries = getAllActivityEntries();
    return allEntries.filter(entry => entry.date === date);
}

// Добавление новой записи об активности
function addActivityEntry(activityData) {
    const keys = getUserStorageKeys();
    if (!keys) return null;
    
    const entries = getAllActivityEntries();
    const newEntry = {
        id: generateId(),
        date: getTodayDate(),
        ...activityData
    };
    entries.push(newEntry);
    localStorage.setItem(keys.ACTIVITY_ENTRIES, JSON.stringify(entries));
    return newEntry;
}

// Удаление записи об активности
function deleteActivityEntry(id) {
    const keys = getUserStorageKeys();
    if (!keys) return [];
    
    const entries = getAllActivityEntries();
    const filteredEntries = entries.filter(entry => entry.id !== id);
    localStorage.setItem(keys.ACTIVITY_ENTRIES, JSON.stringify(filteredEntries));
    return filteredEntries;
}

// Получение статистики за определенную дату
function getDailyStats(date = getTodayDate()) {
    const foodEntries = getFoodEntriesByDate(date);
    const activityEntries = getActivityEntriesByDate(date);
    const goals = getUserGoals();

    const totalCalories = foodEntries.reduce((sum, item) => sum + item.calories, 0);
    const totalProtein = foodEntries.reduce((sum, item) => sum + item.protein, 0);
    const totalCarbs = foodEntries.reduce((sum, item) => sum + item.carbs, 0);
    const totalFat = foodEntries.reduce((sum, item) => sum + item.fat, 0);
    const totalBurnedCalories = activityEntries.reduce((sum, item) => sum + item.calories, 0);
    const totalActivityMinutes = activityEntries.reduce((sum, item) => sum + item.duration, 0);

    return {
        date,
        calories: {
            consumed: totalCalories,
            burned: totalBurnedCalories,
            goal: goals.dailyCalories || 2000
        },
        nutrition: {
            protein: totalProtein,
            carbs: totalCarbs,
            fat: totalFat,
            goals: {
                protein: goals.dailyProtein || 80,
                carbs: goals.dailyCarbs || 250,
                fat: goals.dailyFat || 65
            }
        },
        activity: {
            minutes: totalActivityMinutes,
            goal: goals.dailyActivity || 60
        }
    };
}

// Получение данных за последние 7 дней для графиков
function getWeeklyStats() {
    const dates = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        dates.push(date.toISOString().split('T')[0]);
    }

    const weeklyData = dates.map(date => {
        const stats = getDailyStats(date);
        return {
            date,
            caloriesConsumed: stats.calories.consumed,
            caloriesBurned: stats.calories.burned,
            activityMinutes: stats.activity.minutes
        };
    });

    return weeklyData;
}