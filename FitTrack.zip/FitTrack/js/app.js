// Основной файл приложения (обновленный)

document.addEventListener('DOMContentLoaded', function() {
    // Проверка авторизации
    const currentUser = getCurrentUser();
    
    if (!currentUser) {
        window.location.href = 'index.html';
        return;
    }
    
    // Инициализация приложения
    initTabs();
    initModals();
    loadUserData();
    initializeDefaultData();
    loadDashboardData();
    initLogout();
});

// Инициализация кнопки выхода
function initLogout() {
    const logoutBtn = document.getElementById('logout-btn');
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('Вы уверены, что хотите выйти?')) {
                logout();
            }
        });
    }
}

// Выход из системы
function logout() {
    localStorage.removeItem('fittrack_current_user');
    window.location.href = 'index.html';
}

// Загрузка данных пользователя
function loadUserData() {
    const userData = getCurrentUser();
    
    if (userData) {
        const userNameElement = document.getElementById('user-name');
        const userAvatarElement = document.getElementById('user-avatar');
        
        if (userNameElement) {
            userNameElement.textContent = userData.name;
        }
        
        if (userAvatarElement) {
            // Создаем аватар из инициалов
            const initials = userData.name.split(' ').map(n => n[0]).join('').toUpperCase();
            userAvatarElement.textContent = initials;
        }
    }
}

// Управление вкладками
function initTabs() {
    const tabs = document.querySelectorAll('.tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Убираем активный класс у всех вкладок и контента
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            // Добавляем активный класс текущей вкладке и контенту
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
            
            // Загружаем данные для активной вкладки
            loadTabData(tabId);
        });
    });
}

// Инициализация модальных окон
function initModals() {
    // Модальное окно для добавления еды
    const foodModal = document.getElementById('food-modal');
    const addFoodBtn = document.getElementById('add-food-btn');
    const addNutritionBtn = document.getElementById('add-nutrition-btn');
    const closeFoodModal = foodModal.querySelector('.close');
    
    // Открытие модального окна для еды
    [addFoodBtn, addNutritionBtn].forEach(btn => {
        if (btn) {
            btn.addEventListener('click', function() {
                foodModal.style.display = 'flex';
            });
        }
    });
    
    // Закрытие модального окна для еды
    closeFoodModal.addEventListener('click', function() {
        foodModal.style.display = 'none';
    });
    
    // Модальное окно для добавления активности
    const activityModal = document.getElementById('activity-modal');
    const addActivityBtn = document.getElementById('add-activity-btn');
    const addWorkoutBtn = document.getElementById('add-workout-btn');
    const closeActivityModal = activityModal.querySelector('.close');
    
    // Открытие модального окна для активности
    [addActivityBtn, addWorkoutBtn].forEach(btn => {
        if (btn) {
            btn.addEventListener('click', function() {
                activityModal.style.display = 'flex';
            });
        }
    });
    
    // Закрытие модального окна для активности
    closeActivityModal.addEventListener('click', function() {
        activityModal.style.display = 'none';
    });
    
    // Закрытие модальных окон при клике вне их
    window.addEventListener('click', function(event) {
        if (event.target === foodModal) {
            foodModal.style.display = 'none';
        }
        if (event.target === activityModal) {
            activityModal.style.display = 'none';
        }
    });
}

// Загрузка данных для активной вкладки
function loadTabData(tabId) {
    switch(tabId) {
        case 'nutrition':
            loadNutritionData();
            break;
        case 'activity':
            loadActivityData();
            break;
        case 'progress':
            initCharts();
            break;
        case 'recommendations':
            loadRecommendations();
            break;
    }
}

// Загрузка данных для панели управления
function loadDashboardData() {
    // Загрузка данных о питании
    const todayFoodList = document.getElementById('today-food-list');
    if (todayFoodList) {
        const foodData = getFoodEntriesByDate();
        renderFoodList(todayFoodList, foodData);
    }
    
    // Загрузка данных об активности
    const todayActivityList = document.getElementById('today-activity-list');
    if (todayActivityList) {
        const activityData = getActivityEntriesByDate();
        renderActivityList(todayActivityList, activityData);
    }
    
    // Обновление статистики
    updateDashboardStats();
}

// Обновление статистики на панели управления
function updateDashboardStats() {
    const stats = getDailyStats();
    const goals = getUserGoals();
    
    // Обновление значений на панели
    const calorieElement = document.querySelector('.stats-grid .calories');
    if (calorieElement) {
        calorieElement.textContent = stats.calories.consumed.toLocaleString();
    }
    
    const burnedElement = document.querySelector('.stats-grid .activity-calories');
    if (burnedElement) {
        burnedElement.textContent = stats.calories.burned.toLocaleString();
    }
    
    const proteinElement = document.querySelector('.stats-grid .protein');
    if (proteinElement) {
        proteinElement.textContent = `${stats.nutrition.protein}г`;
    }
    
    // Обновление целей в статистике
    const calorieGoalElement = document.querySelector('.stats-grid .calories + .stat-label');
    if (calorieGoalElement) {
        calorieGoalElement.textContent = `из ${stats.calories.goal} цель`;
    }
    
    const activityGoalElement = document.querySelector('.stats-grid .activity-calories + .stat-label');
    if (activityGoalElement) {
        activityGoalElement.textContent = `цель: ${goals.dailyActivity || 60}`;
    }
    
    const proteinGoalElement = document.querySelector('.stats-grid .protein + .stat-label');
    if (proteinGoalElement) {
        proteinGoalElement.textContent = `цель: ${goals.dailyProtein || 80}г`;
    }
}

// Рендеринг списка еды
function renderFoodList(container, foodData) {
    container.innerHTML = '';
    
    if (foodData.length === 0) {
        container.innerHTML = '<div class="empty-state">Еще нет записей о питании</div>';
        return;
    }
    
    foodData.forEach(food => {
        const foodItem = document.createElement('div');
        foodItem.className = 'food-item';
        foodItem.innerHTML = `
            <div class="food-name">${food.name}</div>
            <div class="food-calories">${food.calories} ккал</div>
        `;
        container.appendChild(foodItem);
    });
}

// Рендеринг списка активности
function renderActivityList(container, activityData) {
    container.innerHTML = '';
    
    if (activityData.length === 0) {
        container.innerHTML = '<div class="empty-state">Еще нет записей об активности</div>';
        return;
    }
    
    activityData.forEach(activity => {
        const activityItem = document.createElement('div');
        activityItem.className = 'activity-item';
        
        // Выбор иконки в зависимости от типа активности
        let icon = '🏃';
        if (activity.type === 'Тренажерный зал') icon = '💪';
        if (activity.type === 'Плавание') icon = '🏊';
        if (activity.type === 'Велосипед') icon = '🚴';
        if (activity.type === 'Йога') icon = '🧘';
        if (activity.type === 'Ходьба') icon = '🚶';
        
        activityItem.innerHTML = `
            <div class="activity-info">
                <div class="activity-icon">${icon}</div>
                <div class="activity-details">
                    <h4>${activity.type}</h4>
                    <p>${activity.duration} мин</p>
                </div>
            </div>
            <div class="activity-calories">${activity.calories} ккал</div>
        `;
        container.appendChild(activityItem);
    });
}