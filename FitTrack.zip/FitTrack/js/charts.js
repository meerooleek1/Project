// Инициализация графиков
function initCharts() {
    initCaloriesChart();
    initActivityChart();
    initNutritionChart();
}

// График калорий
function initCaloriesChart() {
    const ctx = document.getElementById('calories-chart');
    if (!ctx) return;
    
    const weeklyData = getWeeklyStats();
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: weeklyData.map(item => formatChartDate(item.date)),
            datasets: [
                {
                    label: 'Потреблено калорий',
                    data: weeklyData.map(item => item.caloriesConsumed),
                    borderColor: '#4a90e2',
                    backgroundColor: 'rgba(74, 144, 226, 0.1)',
                    tension: 0.3,
                    fill: true
                },
                {
                    label: 'Сожжено калорий',
                    data: weeklyData.map(item => item.caloriesBurned),
                    borderColor: '#7ed321',
                    backgroundColor: 'rgba(126, 211, 33, 0.1)',
                    tension: 0.3,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Баланс калорий за неделю'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Калории'
                    }
                }
            }
        }
    });
}

// График активности
function initActivityChart() {
    const ctx = document.getElementById('activity-chart');
    if (!ctx) return;
    
    const weeklyData = getWeeklyStats();
    const goals = getUserGoals();
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: weeklyData.map(item => formatChartDate(item.date)),
            datasets: [
                {
                    label: 'Активные минуты',
                    data: weeklyData.map(item => item.activityMinutes),
                    backgroundColor: 'rgba(74, 144, 226, 0.7)',
                    yAxisID: 'y'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Активность за неделю'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Минуты'
                    },
                    max: goals.dailyActivity ? goals.dailyActivity * 1.5 : 90
                }
            }
        }
    });
}

// График питательных веществ
function initNutritionChart() {
    const ctx = document.getElementById('nutrition-chart');
    if (!ctx) return;
    
    const stats = getDailyStats();
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Белки', 'Углеводы', 'Жиры'],
            datasets: [{
                data: [stats.nutrition.protein, stats.nutrition.carbs, stats.nutrition.fat],
                backgroundColor: [
                    '#7ed321', // Белки - зеленый
                    '#ffa502', // Углеводы - оранжевый
                    '#ff4757'  // Жиры - красный
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Распределение питательных веществ за сегодня'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value}г (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Форматирование даты для графиков
function formatChartDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}