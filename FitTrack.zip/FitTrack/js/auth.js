// Система авторизации и регистрации

document.addEventListener('DOMContentLoaded', function() {
    // Проверяем, авторизован ли пользователь
    checkAuthStatus();
    
    // Инициализация форм
    initAuthForms();
    
    // Переключение между формами входа и регистрации
    initFormSwitching();
});

// Проверка статуса авторизации
function checkAuthStatus() {
    const currentUser = getCurrentUser();
    if (currentUser && window.location.pathname.endsWith('index.html')) {
        // Если пользователь авторизован и находится на странице входа, перенаправляем на dashboard
        window.location.href = 'dashboard.html';
    } else if (!currentUser && window.location.pathname.endsWith('dashboard.html')) {
        // Если пользователь не авторизован и находится на dashboard, перенаправляем на вход
        window.location.href = 'index.html';
    }
}

// Инициализация форм авторизации
function initAuthForms() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
        // Добавляем проверку силы пароля
        const passwordInput = document.getElementById('register-password');
        const confirmInput = document.getElementById('register-confirm-password');
        
        passwordInput.addEventListener('input', checkPasswordStrength);
        confirmInput.addEventListener('input', checkPasswordMatch);
    }
}

// Переключение между формами входа и регистрации
function initFormSwitching() {
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            switchToRegister();
        });
    }
    
    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            switchToLogin();
        });
    }
}

// Переключение на форму регистрации
function switchToRegister() {
    document.getElementById('login-form').classList.remove('active');
    document.getElementById('register-form').classList.add('active');
    hideMessage();
}

// Переключение на форму входа
function switchToLogin() {
    document.getElementById('register-form').classList.remove('active');
    document.getElementById('login-form').classList.add('active');
    hideMessage();
}

// Обработка входа
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Валидация
    if (!email || !password) {
        showMessage('Заполните все поля', 'error');
        return;
    }
    
    // Поиск пользователя
    const user = findUserByEmail(email);
    
    if (!user) {
        showMessage('Пользователь с таким email не найден', 'error');
        return;
    }
    
    if (user.password !== password) {
        showMessage('Неверный пароль', 'error');
        return;
    }
    
    // Успешный вход
    setCurrentUser(user);
    showMessage('Вход выполнен успешно!', 'success');
    
    // Перенаправление на dashboard
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 1000);
}

// Обработка регистрации
function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    // Валидация
    if (!name || !email || !password || !confirmPassword) {
        showMessage('Заполните все поля', 'error');
        return;
    }
    
    if (password.length < 6) {
        showMessage('Пароль должен содержать не менее 6 символов', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showMessage('Пароли не совпадают', 'error');
        return;
    }
    
    // Проверка существующего пользователя
    if (findUserByEmail(email)) {
        showMessage('Пользователь с таким email уже существует', 'error');
        return;
    }
    
    // Создание нового пользователя
    const newUser = createUser(name, email, password);
    setCurrentUser(newUser);
    
    showMessage('Аккаунт успешно создан!', 'success');
    
    // Перенаправление на dashboard
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 1000);
}

// Проверка силы пароля
function checkPasswordStrength() {
    const password = document.getElementById('register-password').value;
    const strengthElement = document.getElementById('password-strength') || createPasswordStrengthElement();
    
    let strength = 'weak';
    let message = 'Слабый пароль';
    
    if (password.length >= 8) {
        strength = 'medium';
        message = 'Средний пароль';
    }
    
    if (password.length >= 10 && /[A-Z]/.test(password) && /[0-9]/.test(password)) {
        strength = 'strong';
        message = 'Сильный пароль';
    }
    
    strengthElement.textContent = message;
    strengthElement.className = `password-strength strength-${strength}`;
}

// Создание элемента для отображения силы пароля
function createPasswordStrengthElement() {
    const passwordGroup = document.getElementById('register-password').parentElement;
    const strengthElement = document.createElement('div');
    strengthElement.id = 'password-strength';
    strengthElement.className = 'password-strength';
    passwordGroup.appendChild(strengthElement);
    return strengthElement;
}

// Проверка совпадения паролей
function checkPasswordMatch() {
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    const confirmGroup = document.getElementById('register-confirm-password').parentElement;
    
    // Удаляем предыдущее сообщение
    const existingMessage = confirmGroup.querySelector('.password-match-message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    if (confirmPassword && password !== confirmPassword) {
        const messageElement = document.createElement('div');
        messageElement.className = 'password-match-message';
        messageElement.style.color = 'var(--danger)';
        messageElement.style.fontSize = '0.8rem';
        messageElement.style.marginTop = '5px';
        messageElement.textContent = 'Пароли не совпадают';
        confirmGroup.appendChild(messageElement);
    }
}

// Показать сообщение
function showMessage(text, type) {
    const messageElement = document.getElementById('auth-message');
    messageElement.textContent = text;
    messageElement.className = `auth-message ${type}`;
    messageElement.style.display = 'block';
}

// Скрыть сообщение
function hideMessage() {
    const messageElement = document.getElementById('auth-message');
    messageElement.style.display = 'none';
}

// ===== ФУНКЦИИ ДЛЯ РАБОТЫ С ПОЛЬЗОВАТЕЛЯМИ =====

// Ключи для localStorage
const AUTH_KEYS = {
    USERS: 'fittrack_users',
    CURRENT_USER: 'fittrack_current_user'
};

// Получить всех пользователей
function getAllUsers() {
    return JSON.parse(localStorage.getItem(AUTH_KEYS.USERS) || '[]');
}

// Сохранить пользователей
function saveUsers(users) {
    localStorage.setItem(AUTH_KEYS.USERS, JSON.stringify(users));
}

// Найти пользователя по email
function findUserByEmail(email) {
    const users = getAllUsers();
    return users.find(user => user.email === email);
}

// Создать нового пользователя
function createUser(name, email, password) {
    const users = getAllUsers();
    
    const newUser = {
        id: generateUserId(),
        name: name,
        email: email,
        password: password,
        createdAt: new Date().toISOString(),
        goals: {
            dailyCalories: 2000,
            dailyProtein: 80,
            dailyCarbs: 250,
            dailyFat: 65,
            dailySteps: 10000,
            dailyActivity: 60
        }
    };
    
    users.push(newUser);
    saveUsers(users);
    
    // Создаем отдельное хранилище для данных пользователя
    initializeUserData(newUser.id);
    
    return newUser;
}

// Генерация ID пользователя
function generateUserId() {
    return 'user_' + Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Установить текущего пользователя
function setCurrentUser(user) {
    localStorage.setItem('fittrack_current_user', JSON.stringify(user));
}

// Получить текущего пользователя
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('fittrack_current_user') || 'null');
}

// Выход из системы
function logout() {
    localStorage.removeItem('fittrack_current_user');
    window.location.href = 'index.html';
}

// Инициализация данных пользователя
function initializeUserData(userId) {
    const userFoodKey = `fittrack_food_entries_${userId}`;
    const userActivityKey = `fittrack_activity_entries_${userId}`;
    
    if (!localStorage.getItem(userFoodKey)) {
        const defaultFoodEntries = [
            { 
                id: generateId(),
                name: 'Овсяная каша', 
                calories: 150, 
                protein: 5, 
                carbs: 25, 
                fat: 3, 
                time: '08:30',
                date: getTodayDate()
            }
        ];
        localStorage.setItem(userFoodKey, JSON.stringify(defaultFoodEntries));
    }
    
    if (!localStorage.getItem(userActivityKey)) {
        const defaultActivityEntries = [
            {
                id: generateId(),
                type: 'Ходьба',
                duration: 30,
                calories: 120,
                date: getTodayDate(),
                time: '18:00'
            }
        ];
        localStorage.setItem(userActivityKey, JSON.stringify(defaultActivityEntries));
    }
}

// Вспомогательные функции
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function getTodayDate() {
    return new Date().toISOString().split('T')[0];
}