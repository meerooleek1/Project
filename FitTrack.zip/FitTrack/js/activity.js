// Функциональность для вкладки "Активность"

// Загрузка данных об активности
function loadActivityData() {
    const workoutList = document.getElementById('workout-list');
    if (workoutList) {
        const activityData = getAllActivityEntries();
        renderWorkoutList(workoutList, activityData);
    }
    
    // Инициализация формы добавления активности
    initActivityForm();
}

// Рендеринг списка тренировок
function renderWorkoutList(container, activityData) {
    container.innerHTML = '';
    
    if (activityData.length === 0) {
        container.innerHTML = '<div class="empty-state">Еще нет записей об активности</div>';
        return;
    }
    
    // Сортировка по дате (новые сверху)
    activityData.sort((a, b) => new Date(b.date + ' ' + b.time) - new Date(a.date + ' ' + a.time));
    
    activityData.forEach(activity => {
        const activityItem = document.createElement('div');
        activityItem.className = 'activity-item';
        
        // Выбор иконки в зависимости от типа активности
        let icon = '🏃';
        if (activity.type === 'Тренажерный зал') icon = '💪';
        if (activity.type === 'Плавание') icon = '🏊';
        if (activity.type === 'Велосипед') icon = '🚴';
        if (activity.type === 'Йога') icon = '🧘';
        if (activity.type === 'Ходьба') icon = '🚶';
        
        activityItem.innerHTML = `
            <div class="activity-info">
                <div class="activity-icon">${icon}</div>
                <div class="activity-details">
                    <h4>${activity.type}</h4>
                    <p>${activity.duration} мин • ${formatDate(activity.date)} ${activity.time}</p>
                </div>
            </div>
            <div class="activity-calories">${activity.calories} ккал</div>
        `;
        container.appendChild(activityItem);
    });
}

// Форматирование даты
function formatDate(dateString) {
    const options = { day: 'numeric', month: 'short' };
    return new Date(dateString).toLocaleDateString('ru-RU', options);
}

// Инициализация формы добавления активности
function initActivityForm() {
    const activityForm = document.getElementById('activity-form');
    
    if (activityForm) {
        // Установка сегодняшней даты по умолчанию
        document.getElementById('activity-date').value = getTodayDate();
        
        activityForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Получение данных из формы
            const activityType = document.getElementById('activity-type').value;
            const activityDuration = parseInt(document.getElementById('activity-duration').value);
            const activityCalories = parseInt(document.getElementById('activity-calories').value);
            const activityDate = document.getElementById('activity-date').value;
            
            // Добавление новой активности
            addNewActivity({
                type: activityType,
                duration: activityDuration,
                calories: activityCalories,
                date: activityDate,
                time: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
            });
            
            // Закрытие модального окна и сброс формы
            document.getElementById('activity-modal').style.display = 'none';
            activityForm.reset();
            // Снова устанавливаем сегодняшнюю дату
            document.getElementById('activity-date').value = getTodayDate();
        });
    }
}

// Добавление новой активности в систему
function addNewActivity(activityData) {
    addActivityEntry(activityData);
    
    // Обновление интерфейса
    loadActivityData();
    loadDashboardData();
}