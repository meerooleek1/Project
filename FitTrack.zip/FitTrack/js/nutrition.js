// Функциональность для вкладки "Питание"

// Загрузка данных о питании
function loadNutritionData() {
    const nutritionList = document.getElementById('nutrition-list');
    if (nutritionList) {
        const foodData = getFoodEntriesByDate();
        renderNutritionList(nutritionList, foodData);
        updateNutritionSummary(foodData);
    }
    
    // Инициализация формы добавления еды
    initFoodForm();
}

// Рендеринг списка питания
function renderNutritionList(container, foodData) {
    container.innerHTML = '';
    
    if (foodData.length === 0) {
        container.innerHTML = '<div class="empty-state">Еще нет записей о питании за сегодня</div>';
        return;
    }
    
    foodData.forEach(food => {
        const foodItem = document.createElement('div');
        foodItem.className = 'food-item';
        foodItem.innerHTML = `
            <div>
                <div class="food-name">${food.name}</div>
                <div style="font-size: 0.8rem; color: var(--gray);">${food.time}</div>
            </div>
            <div class="food-calories">${food.calories} ккал</div>
        `;
        container.appendChild(foodItem);
    });
}

// Обновление сводки по питательным веществам
function updateNutritionSummary(foodData) {
    const stats = getDailyStats();
    const goals = getUserGoals();
    
    // Обновление значений в интерфейсе
    const calorieElement = document.querySelector('.nutrition-summary .calories');
    if (calorieElement) {
        calorieElement.textContent = stats.calories.consumed;
    }
    
    const proteinElement = document.querySelector('.nutrition-summary .protein');
    if (proteinElement) {
        proteinElement.textContent = `${stats.nutrition.protein}г`;
    }
    
    const carbsElement = document.querySelector('.nutrition-summary .carbs');
    if (carbsElement) {
        carbsElement.textContent = `${stats.nutrition.carbs}г`;
    }
    
    const fatElement = document.querySelector('.nutrition-summary .fat');
    if (fatElement) {
        fatElement.textContent = `${stats.nutrition.fat}г`;
    }
    
    // Обновление целей
    const calorieGoalElement = document.querySelector('.nutrition-summary .calories + .nutrition-label');
    if (calorieGoalElement) {
        calorieGoalElement.textContent = `из ${stats.calories.goal}`;
    }
    
    const proteinGoalElement = document.querySelector('.nutrition-summary .protein + .nutrition-label');
    if (proteinGoalElement) {
        proteinGoalElement.textContent = `${goals.dailyProtein || 80}г`;
    }
    
    const carbsGoalElement = document.querySelector('.nutrition-summary .carbs + .nutrition-label');
    if (carbsGoalElement) {
        carbsGoalElement.textContent = `${goals.dailyCarbs || 250}г`;
    }
    
    const fatGoalElement = document.querySelector('.nutrition-summary .fat + .nutrition-label');
    if (fatGoalElement) {
        fatGoalElement.textContent = `${goals.dailyFat || 65}г`;
    }
}

// Инициализация формы добавления еды
function initFoodForm() {
    const foodForm = document.getElementById('food-form');
    
    if (foodForm) {
        foodForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Получение данных из формы
            const foodName = document.getElementById('food-name').value;
            const foodCalories = parseInt(document.getElementById('food-calories').value);
            const foodProtein = parseInt(document.getElementById('food-protein').value);
            const foodCarbs = parseInt(document.getElementById('food-carbs').value);
            const foodFat = parseInt(document.getElementById('food-fat').value);
            const foodTime = document.getElementById('food-time').value;
            
            // Добавление новой еды
            addNewFood({
                name: foodName,
                calories: foodCalories,
                protein: foodProtein,
                carbs: foodCarbs,
                fat: foodFat,
                time: foodTime
            });
            
            // Закрытие модального окна и сброс формы
            document.getElementById('food-modal').style.display = 'none';
            foodForm.reset();
        });
    }
}

// Добавление новой еды в систему
function addNewFood(foodData) {
    addFoodEntry(foodData);
    
    // Обновление интерфейса
    loadNutritionData();
    loadDashboardData();
}